# Zaitar 🌷

An Instagram-inspired, full-stack social media starter website built with HTML, CSS, JavaScript, Node.js, and Express.

## Features

- Create an account and log in (passwords are hashed with bcrypt)
- Session-based authentication
- Community feed with text captions and optional image URLs
- Like/unlike posts
- Add comments
- Search for people by name or username
- Follow/unfollow users
- Edit your display name, bio, and profile-picture URL
- Responsive layout for phones and computers
- Persistent starter data stored in `data/db.json`

## Run it locally

1. Install **Node.js 18 or newer** from the official Node.js website.
2. Extract this project folder.
3. Open a terminal in the `zaitar-social` folder.
4. Run:

   ```bash
   npm install
   npm start
   ```

5. Open `http://localhost:3000` in your browser.

For automatic restarts while developing, use `npm run dev`.

## Upload it to GitHub

1. Create a new, empty repository on GitHub named `zaitar-social`.
2. In a terminal opened inside this folder, run:

   ```bash
   git init
   git add .
   git commit -m "Build Zaitar social website"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/zaitar-social.git
   git push -u origin main
   ```

3. Replace `YOUR-USERNAME` with your GitHub username.

Do not upload passwords, secret keys, `.env` files, or private user data.

## Important production notes

This is a learning/demo starter, not yet ready for a public production launch.

- The JSON file database is suitable only for local demos and can lose data on some hosting platforms. Use a managed database (such as PostgreSQL) for a real launch.
- The default Express session store is in-memory. Configure a persistent session store before deployment.
- Set a strong, random `SESSION_SECRET` environment variable before deployment. Never use the development fallback secret publicly.
- Use HTTPS, add rate limiting and CSRF protections, and review privacy, moderation, accessibility, and data-retention requirements before inviting real users.
- Image links are stored as URLs; this starter does not upload image files.
- The included profile editor uses simple browser prompts to keep the starter easy to understand. It can be upgraded to a polished profile settings page.

## Project structure

```text
zaitar-social/
├── data/
│   └── .gitkeep
├── public/
│   ├── app.js
│   ├── index.html
│   └── style.css
├── .gitignore
├── package.json
├── README.md
└── server.js
```

## License

This project is provided for learning and personal customization. Add a specific open-source license if you want to define permissions for reuse and redistribution.

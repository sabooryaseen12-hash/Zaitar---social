const $ = id => document.getElementById(id);
let me = null;
let authMode = "login";
let searchTimer;

function escapeHTML(value = "") {
  return String(value).replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
}
function avatar(user, extra = "") {
  const initial = escapeHTML((user?.name || user?.username || "Z").slice(0, 1).toUpperCase());
  const inside = user?.avatar ? `<img src="${escapeHTML(user.avatar)}" alt="" onerror="this.remove()">` : initial;
  return `<div class="avatar ${extra}">${inside}</div>`;
}
async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: "same-origin",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}
let toastTimer;
function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2600);
}
function timeAgo(date) {
  const seconds = Math.max(0, Math.floor((Date.now() - new Date(date).getTime()) / 1000));
  if (seconds < 60) return "just now";
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}
function updateUI() {
  $("composer").classList.toggle("hidden", !me);
  $("authPrompt").classList.toggle("hidden", !!me);
  $("logoutBtn").classList.toggle("hidden", !me);
  $("authOpenBtn").textContent = me ? "Edit your profile ✎" : "Join the community ↗";
  $("accountSummary").innerHTML = me
    ? `${avatar(me)}<div><strong>${escapeHTML(me.name)}</strong><small>@${escapeHTML(me.username)} · ${me.followers} followers</small></div>`
    : `${avatar({ name: "Z" })}<div><strong>Welcome to Zaitar</strong><small>Sign in to join the conversation.</small></div>`;
  $("composerAvatar").innerHTML = me?.avatar ? `<img src="${escapeHTML(me.avatar)}" alt="">` : escapeHTML((me?.name || "Z").slice(0, 1).toUpperCase());
}
async function loadMe() {
  const data = await api("/api/me");
  me = data.user;
  updateUI();
}
async function loadFeed() {
  const feed = $("feed");
  feed.innerHTML = '<div class="loading">Gathering the good stuff…</div>';
  try {
    const { posts } = await api("/api/feed");
    if (!posts.length) {
      feed.innerHTML = `<div class="empty-state">🌷<br><br>No moments have been shared yet.<br>${me ? "Be the first to post something!" : "Create an account and start the first conversation."}</div>`;
      return;
    }
    feed.innerHTML = posts.map(renderPost).join("");
  } catch (error) {
    feed.innerHTML = `<div class="empty-state">${escapeHTML(error.message)}</div>`;
  }
}
function renderPost(post) {
  const comments = (post.comments || []).map(c => `<div class="comment"><strong>@${escapeHTML(c.author.username)}</strong>${escapeHTML(c.text)}</div>`).join("");
  const image = post.imageUrl ? `<img class="post-image" src="${escapeHTML(post.imageUrl)}" alt="Photo shared by ${escapeHTML(post.author.username)}" loading="lazy" onerror="this.style.display='none'">` : "";
  const commentForm = me ? `<form class="comment-form" data-comment="${post.id}"><input name="text" maxlength="250" required placeholder="Add a kind comment…"><button type="submit">Send</button></form>` : "";
  return `<article class="post-card" id="post-${post.id}">
    <div class="post-head">${avatar(post.author)}<div class="post-author"><strong>${escapeHTML(post.author.name)} <span style="font-weight:400;color:#aaa">@${escapeHTML(post.author.username)}</span></strong><small>${timeAgo(post.createdAt)}</small></div><span class="post-time">✦</span></div>
    ${image}
    ${post.caption ? `<div class="post-caption">${escapeHTML(post.caption)}</div>` : ""}
    <div class="post-actions"><button class="action-btn ${post.liked ? "liked" : ""}" data-like="${post.id}">${post.liked ? "♥ Liked" : "♡ Like"}</button><button class="action-btn" data-focus-comment="${post.id}">♡ Comment</button><span class="like-count">${post.likes.length} ${post.likes.length === 1 ? "like" : "likes"}</span></div>
    <div class="comments">${comments}${commentForm}</div>
  </article>`;
}
async function loadPeople(query = "") {
  if (!me) {
    $("peopleList").innerHTML = '<p class="muted">Log in to discover people and follow their updates.</p>';
    return;
  }
  try {
    const { users } = await api(`/api/users?q=${encodeURIComponent(query)}`);
    $("peopleList").innerHTML = users.length ? users.slice(0, 5).map(user => `
      <div class="person-row">${avatar(user)}<div class="person-info"><strong>${escapeHTML(user.name)}</strong><small>@${escapeHTML(user.username)}</small></div>
      <button class="follow-btn ${user.isFollowing ? "following" : ""}" data-follow="${user.id}">${user.isFollowing ? "Following" : "Follow"}</button></div>`).join("") : '<p class="muted">No people found. Try another search.</p>';
  } catch { $("peopleList").innerHTML = '<p class="muted">Could not load people right now.</p>'; }
}
function openAuth(mode = "login") {
  authMode = mode;
  $("authError").textContent = "";
  $("authModal").classList.remove("hidden");
  $("authTitle").textContent = mode === "login" ? "Come on in." : "Your space awaits.";
  $("loginTab").classList.toggle("active", mode === "login");
  $("registerTab").classList.toggle("active", mode === "register");
  $("nameField").classList.toggle("hidden", mode !== "register");
  $("authSubmit").innerHTML = mode === "login" ? 'Log in <span>↗</span>' : 'Create account <span>↗</span>';
  $("passwordInput").autocomplete = mode === "login" ? "current-password" : "new-password";
}
function closeAuth() { $("authModal").classList.add("hidden"); }
async function refresh() { await loadMe(); await Promise.all([loadFeed(), loadPeople()]); }

$("authOpenBtn").addEventListener("click", () => me ? openProfileEditor() : openAuth("register"));
$("promptAuthBtn").addEventListener("click", () => openAuth("register"));
$("closeModal").addEventListener("click", closeAuth);
$("loginTab").addEventListener("click", () => openAuth("login"));
$("registerTab").addEventListener("click", () => openAuth("register"));
$("authModal").addEventListener("click", e => { if (e.target === $("authModal")) closeAuth(); });
$("homeBtn").addEventListener("click", () => { $("searchInput").value = ""; loadFeed(); });
$("profileBtn").addEventListener("click", () => me ? openProfileEditor() : openAuth("login"));
$("logoutBtn").addEventListener("click", async () => {
  await api("/api/logout", { method: "POST", body: "{}" });
  me = null; updateUI(); await Promise.all([loadFeed(), loadPeople()]); toast("You’ve logged out. See you soon!");
});
$("authForm").addEventListener("submit", async e => {
  e.preventDefault();
  $("authError").textContent = "";
  const payload = { username: $("usernameInput").value, password: $("passwordInput").value };
  if (authMode === "register") payload.name = $("nameInput").value;
  try {
    const data = await api(`/api/${authMode === "login" ? "login" : "register"}`, { method: "POST", body: JSON.stringify(payload) });
    me = data.user; closeAuth(); updateUI(); await Promise.all([loadFeed(), loadPeople()]); toast(`Welcome${authMode === "login" ? " back" : ""}, ${me.name}!`);
    $("authForm").reset();
  } catch (error) { $("authError").textContent = error.message; }
});
$("postBtn").addEventListener("click", async () => {
  const caption = $("captionInput").value.trim();
  const imageUrl = $("imageInput").value.trim();
  $("postBtn").disabled = true;
  try {
    await api("/api/posts", { method: "POST", body: JSON.stringify({ caption, imageUrl }) });
    $("captionInput").value = ""; $("imageInput").value = "";
    await loadFeed(); toast("Your moment is out in the world ✨");
  } catch (error) { toast(error.message); }
  finally { $("postBtn").disabled = false; }
});
$("feed").addEventListener("click", async e => {
  const like = e.target.closest("[data-like]");
  const focus = e.target.closest("[data-focus-comment]");
  if (like) {
    if (!me) return openAuth("login");
    try { await api(`/api/posts/${like.dataset.like}/like`, { method: "POST", body: "{}" }); await loadFeed(); }
    catch (error) { toast(error.message); }
  }
  if (focus) {
    if (!me) return openAuth("login");
    const input = document.querySelector(`[data-comment="${focus.dataset.focusComment}"] input`);
    input?.focus();
  }
});
$("feed").addEventListener("submit", async e => {
  const form = e.target.closest("[data-comment]");
  if (!form) return;
  e.preventDefault();
  const input = form.elements.text;
  try { await api(`/api/posts/${form.dataset.comment}/comments`, { method: "POST", body: JSON.stringify({ text: input.value }) }); await loadFeed(); }
  catch (error) { toast(error.message); }
});
$("peopleList").addEventListener("click", async e => {
  const button = e.target.closest("[data-follow]");
  if (!button) return;
  try { await api(`/api/users/${button.dataset.follow}/follow`, { method: "POST", body: "{}" }); await loadMe(); await loadPeople($("searchInput").value.trim()); toast("Your community just got a little closer."); }
  catch (error) { toast(error.message); }
});
$("searchInput").addEventListener("input", () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => loadPeople($("searchInput").value.trim()), 250);
});
async function openProfileEditor() {
  if (!me) return openAuth("login");
  const name = prompt("Your display name:", me.name);
  if (name === null) return;
  const bio = prompt("A short bio (optional):", me.bio || "");
  if (bio === null) return;
  const avatarUrl = prompt("Profile picture URL (optional; leave blank to remove):", me.avatar || "");
  if (avatarUrl === null) return;
  try {
    const data = await api("/api/profile", { method: "PATCH", body: JSON.stringify({ name, bio, avatar: avatarUrl }) });
    me = data.user; updateUI(); await loadPeople($("searchInput").value.trim()); toast("Profile updated ✨");
  } catch (error) { toast(error.message); }
}
refresh().catch(() => { loadFeed(); loadPeople(); });

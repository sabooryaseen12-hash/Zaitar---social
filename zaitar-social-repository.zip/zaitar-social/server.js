const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const DB_FILE = path.join(DATA_DIR, "db.json");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(DB_FILE, JSON.stringify({ users: [], posts: [], nextUserId: 1, nextPostId: 1 }, null, 2));
}

function readDB() {
  return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
}
function writeDB(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}
function publicUser(user, viewerId) {
  const db = readDB();
  return {
    id: user.id,
    username: user.username,
    name: user.name,
    bio: user.bio || "",
    avatar: user.avatar || "",
    followers: db.users.filter(u => (u.following || []).includes(user.id)).length,
    following: (user.following || []).length,
    isFollowing: viewerId ? !!(db.users.find(u => u.id === viewerId)?.following || []).includes(user.id) : false
  };
}
function safePost(post, viewerId) {
  const db = readDB();
  const author = db.users.find(u => u.id === post.userId);
  if (!author) return null;
  return {
    id: post.id,
    caption: post.caption,
    imageUrl: post.imageUrl || "",
    createdAt: post.createdAt,
    author: publicUser(author, viewerId),
    likes: post.likes || [],
    liked: !!viewerId && (post.likes || []).includes(viewerId),
    comments: (post.comments || []).map(c => ({
      id: c.id,
      text: c.text,
      createdAt: c.createdAt,
      author: publicUser(db.users.find(u => u.id === c.userId) || { id: 0, username: "deleted", name: "Deleted user" }, viewerId)
    }))
  };
}
function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Please log in first." });
  next();
}
function cleanText(value, max = 500) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

app.use(express.json({ limit: "200kb" }));
app.use(session({
  name: "zaitar.sid",
  secret: process.env.SESSION_SECRET || "change-this-development-secret-before-deploying",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 7 * 24 * 60 * 60 * 1000
  }
}));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/me", (req, res) => {
  if (!req.session.userId) return res.json({ user: null });
  const db = readDB();
  const user = db.users.find(u => u.id === req.session.userId);
  if (!user) return res.json({ user: null });
  res.json({ user: publicUser(user, user.id) });
});

app.post("/api/register", async (req, res) => {
  const username = cleanText(req.body.username, 20).toLowerCase();
  const name = cleanText(req.body.name, 40);
  const password = typeof req.body.password === "string" ? req.body.password : "";
  if (!/^[a-z0-9_]{3,20}$/.test(username)) return res.status(400).json({ error: "Username must be 3–20 characters (letters, numbers, underscores)." });
  if (name.length < 1) return res.status(400).json({ error: "Please enter your name." });
  if (password.length < 8) return res.status(400).json({ error: "Password must be at least 8 characters." });
  const db = readDB();
  if (db.users.some(u => u.username === username)) return res.status(409).json({ error: "That username is already taken." });
  const user = {
    id: db.nextUserId++, username, name,
    passwordHash: await bcrypt.hash(password, 12),
    bio: "", avatar: "", following: [], createdAt: new Date().toISOString()
  };
  db.users.push(user);
  writeDB(db);
  req.session.userId = user.id;
  res.status(201).json({ user: publicUser(user, user.id) });
});

app.post("/api/login", async (req, res) => {
  const username = cleanText(req.body.username, 20).toLowerCase();
  const password = typeof req.body.password === "string" ? req.body.password : "";
  const db = readDB();
  const user = db.users.find(u => u.username === username);
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
    return res.status(401).json({ error: "Username or password is incorrect." });
  }
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not start your session." });
    req.session.userId = user.id;
    res.json({ user: publicUser(user, user.id) });
  });
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get("/api/feed", (req, res) => {
  const db = readDB();
  const posts = [...db.posts].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .map(p => safePost(p, req.session.userId)).filter(Boolean);
  res.json({ posts });
});

app.post("/api/posts", requireAuth, (req, res) => {
  const caption = cleanText(req.body.caption, 500);
  const imageUrl = cleanText(req.body.imageUrl, 1000);
  if (!caption && !imageUrl) return res.status(400).json({ error: "Add a caption or an image URL." });
  if (imageUrl && !/^https?:\/\/\S+$/i.test(imageUrl)) return res.status(400).json({ error: "Image URL must start with http:// or https://." });
  const db = readDB();
  const post = {
    id: db.nextPostId++, userId: req.session.userId, caption, imageUrl,
    createdAt: new Date().toISOString(), likes: [], comments: []
  };
  db.posts.push(post);
  writeDB(db);
  res.status(201).json({ post: safePost(post, req.session.userId) });
});

app.post("/api/posts/:id/like", requireAuth, (req, res) => {
  const db = readDB();
  const post = db.posts.find(p => p.id === Number(req.params.id));
  if (!post) return res.status(404).json({ error: "Post not found." });
  post.likes = post.likes || [];
  const index = post.likes.indexOf(req.session.userId);
  if (index >= 0) post.likes.splice(index, 1);
  else post.likes.push(req.session.userId);
  writeDB(db);
  res.json({ post: safePost(post, req.session.userId) });
});

app.post("/api/posts/:id/comments", requireAuth, (req, res) => {
  const text = cleanText(req.body.text, 250);
  if (!text) return res.status(400).json({ error: "Write a comment first." });
  const db = readDB();
  const post = db.posts.find(p => p.id === Number(req.params.id));
  if (!post) return res.status(404).json({ error: "Post not found." });
  post.comments = post.comments || [];
  post.comments.push({ id: Date.now(), userId: req.session.userId, text, createdAt: new Date().toISOString() });
  writeDB(db);
  res.status(201).json({ post: safePost(post, req.session.userId) });
});

app.get("/api/users", (req, res) => {
  const q = cleanText(req.query.q, 30).toLowerCase();
  const db = readDB();
  const users = db.users
    .filter(u => u.id !== req.session.userId && (!q || u.username.includes(q) || u.name.toLowerCase().includes(q)))
    .slice(0, 30)
    .map(u => publicUser(u, req.session.userId));
  res.json({ users });
});

app.get("/api/users/:username", (req, res) => {
  const db = readDB();
  const user = db.users.find(u => u.username === cleanText(req.params.username, 20).toLowerCase());
  if (!user) return res.status(404).json({ error: "Profile not found." });
  const posts = db.posts.filter(p => p.userId === user.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .map(p => safePost(p, req.session.userId));
  res.json({ user: publicUser(user, req.session.userId), posts });
});

app.post("/api/users/:id/follow", requireAuth, (req, res) => {
  const targetId = Number(req.params.id);
  if (targetId === req.session.userId) return res.status(400).json({ error: "You cannot follow yourself." });
  const db = readDB();
  const me = db.users.find(u => u.id === req.session.userId);
  const target = db.users.find(u => u.id === targetId);
  if (!target) return res.status(404).json({ error: "User not found." });
  me.following = me.following || [];
  const index = me.following.indexOf(targetId);
  if (index >= 0) me.following.splice(index, 1);
  else me.following.push(targetId);
  writeDB(db);
  res.json({ user: publicUser(target, me.id) });
});

app.patch("/api/profile", requireAuth, (req, res) => {
  const name = cleanText(req.body.name, 40);
  const bio = cleanText(req.body.bio, 160);
  const avatar = cleanText(req.body.avatar, 1000);
  if (!name) return res.status(400).json({ error: "Name cannot be empty." });
  if (avatar && !/^https?:\/\/\S+$/i.test(avatar)) return res.status(400).json({ error: "Avatar URL must start with http:// or https://." });
  const db = readDB();
  const me = db.users.find(u => u.id === req.session.userId);
  me.name = name; me.bio = bio; me.avatar = avatar;
  writeDB(db);
  res.json({ user: publicUser(me, me.id) });
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`Zaitar is running at http://localhost:${PORT}`));
